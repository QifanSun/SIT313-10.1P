const mongoose = require("mongoose");

const TaskSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "title name is required."],
  },
  task1: {
    type: String,
    required: [true, "task1 name is required."],
  },
  description: {
    type: String,
    required: [true, "description name is required."],
  },
  date: {
    type: String,
    required: [true, "date name is required."],
  },
  master: {
    type: String,
    required: [true, "master name is required."],
  },
  reward: {
    type: String,
    required: [true, "reward name is required."],
  },
  number: {
    type: String,
    required: [true, "number name is required."],
  },
});

const Task = mongoose.model("Task", TaskSchema);
module.exports = { Task };
